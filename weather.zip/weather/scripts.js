function hide(element){

cky.remove();
}

function change(element){
    alert("Loading weather report...");
}

function convert(element){
if(c_cold1 == c_cold1){
    c_cold1.replaceWith(f_cold1);
}
if(c_hot1 == c_hot1){
    c_hot1.replaceWith(f_hot1);
}
if(c_cold2 == c_cold2){
    c_cold2.replaceWith(f_cold2);
}
if(c_hot2 == c_hot2){
    c_hot2.replaceWith(f_hot2);
}
if(c_cold3 == c_cold3){
    c_cold3.replaceWith(f_cold3);
}
if(c_hot3 == c_hot3){
    c_hot3.replaceWith(f_hot3);
}
if(c_cold4 == c_cold4){
    c_cold4.replaceWith(f_cold4);
}
if(c_hot4 == c_hot4){
    c_hot4.replaceWith(f_hot4);
}
}

var f = document.querySelector(".farenheit");
var cky = document.querySelector(".cookie");
var c_cold1 = document.querySelector("#tempc1");
var c_hot1 = document.querySelector("#temph1");
var f_cold1 = document.querySelector("#ftempc1");
var f_hot1 = document.querySelector("#ftemph1");
var c_cold2 = document.querySelector("#tempc2");
var c_hot2 = document.querySelector("#temph2");
var f_cold2 = document.querySelector("#ftempc2");
var f_hot2 = document.querySelector("#ftemph2");
var c_cold3 = document.querySelector("#tempc3");
var c_hot3 = document.querySelector("#temph3");
var f_cold3 = document.querySelector("#ftempc3");
var f_hot3 = document.querySelector("#ftemph3");
var c_cold4 = document.querySelector("#tempc4");
var c_hot4 = document.querySelector("#temph4");
var f_cold4 = document.querySelector("#ftempc4");
var f_hot4 = document.querySelector("#ftemph4");