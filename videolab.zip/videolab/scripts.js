function logout(element){
    element.innerText = "Logout";
}

function play(element){
    videoObject.muted = true;
}

function  pause(element){
    videoObject.muted = true;
}
function unsubscribe(element){
    element.innerText ="Unsubscribe";
}