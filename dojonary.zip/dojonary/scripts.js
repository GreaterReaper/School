function logout(element){
    element.innerText = "Logout";
}
function like(element){
    element.innerText = "14 likes";
    alert('Ninja was liked')
}
function like2(element){
    element.innerText = "38 likes";
    alert('Ninja was liked')
}
function adddef(element) {
    element.remove();
}
