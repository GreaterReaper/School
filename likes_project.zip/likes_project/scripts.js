var likes1= 9;
var like1Element = document.querySelector("#likes1");

function like1(element){
likes1++;
like1Element.innerText = likes1 + "like(s)"
}
var likes2= 12;
var like2Element = document.querySelector("#likes2");

function like2(element){
likes2++;
like2Element.innerText = likes2 + "like(s)"
}
var likes3= 9;
var like3Element = document.querySelector("#likes3");

function like3(element){
likes3++;
like3Element.innerText = likes3 + "like(s)"
}